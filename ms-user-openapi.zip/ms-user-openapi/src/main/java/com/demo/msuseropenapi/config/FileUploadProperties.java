package com.demo.msuseropenapi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@ConfigurationProperties(prefix = "file")
public class FileUploadProperties {

    private String uploadDir;

}
