package com.demo.msuseropenapi.service;

import com.demo.msuseropenapi.config.FileUploadProperties;
import lombok.SneakyThrows;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class FileUploadServiceImpl implements FileUploadService{

    private final Path fileUploadLocation;

    @SneakyThrows
    @Autowired
    public FileUploadServiceImpl(FileUploadProperties fileStorageProperties, ServletContext context){
        this.fileUploadLocation = Paths.get(context.getRealPath(fileStorageProperties.getUploadDir()))
                .toAbsolutePath().normalize();
        try {
            Files.createDirectories(this.fileUploadLocation);
        } catch (Exception ex) {
            throw new FileUploadException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    @SneakyThrows
    public String storeFile(MultipartFile file, String fnameId) {
        // Normalize file naFileUploadExceptionme
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        fileName=fnameId+"_"+fileName;

        try {
            // Check if the file's name contains invalid characters
            if(fileName.contains("..")) {
                throw new FileUploadException("Sorry! Filename contains invalid path sequence " + fileName);
            }

            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.fileUploadLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return fileName;
        } catch (IOException ex) {
            throw new FileUploadException("Could not store file " + fileName + ". Please try again!", ex);
        }
    }

    public Resource loadFileAsResource(String fileName) {
        try {
            Path filePath = this.fileUploadLocation.resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if(resource.exists()) {
                return resource;
            } else {
                throw new RuntimeException("File not found " + fileName);
            }
        } catch (MalformedURLException ex) {
            throw new RuntimeException("File not found " + fileName, ex);
        }
    }

}
