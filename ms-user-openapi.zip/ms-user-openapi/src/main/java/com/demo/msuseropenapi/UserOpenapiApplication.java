package com.demo.msuseropenapi;

import com.demo.msuseropenapi.config.AppCorsConfig;
import com.demo.msuseropenapi.config.FileUploadProperties;
import com.demo.msuseropenapi.config.UsersConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import({UsersConfig.class, AppCorsConfig.class})
@EnableConfigurationProperties({
		FileUploadProperties.class
})
public class UserOpenapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserOpenapiApplication.class, args);
	}

}
