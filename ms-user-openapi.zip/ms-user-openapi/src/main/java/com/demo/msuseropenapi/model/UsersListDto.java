package com.demo.msuseropenapi.model;

import com.demo.msuseropenapi.entity.User;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.util.List;

@Setter
@Getter
@ToString
public class UsersListDto {

    List<User> users;
    int totalUsers;
    int totalPages;
    int currentPage;

}
