package com.demo.msuseropenapi.config;

import com.demo.msuseropenapi.service.UserServices;
import com.demo.msuseropenapi.service.UserServicesImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UsersConfig {

    @Bean
    public UserServices userServices(){
        return new UserServicesImpl();
    }
}
