package com.demo.msuseropenapi.config;

import com.demo.msuseropenapi.service.FileUploadService;
import com.demo.msuseropenapi.service.FileUploadServiceImpl;
import com.demo.msuseropenapi.service.UserServices;
import com.demo.msuseropenapi.service.UserServicesImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.ServletContext;

@Configuration
public class UsersConfig {

    @Bean
    public UserServices userServices(){
        return new UserServicesImpl();
    }

    @Bean
    public FileUploadProperties fileUploadProperties(){
        return new FileUploadProperties();
    }

    @Bean
    public FileUploadService fileUploadService(FileUploadProperties fileUploadProperties, ServletContext context) {
        return new FileUploadServiceImpl(fileUploadProperties,context);
    }

}
