package com.demo.msuseropenapi.service;

import com.demo.msuseropenapi.entity.User;
import com.demo.msuseropenapi.model.UsersListDto;
import com.demo.msuseropenapi.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UserServicesImpl implements UserServices{

    @Autowired
    UsersRepository usersRepository;

    @Override
    public ResponseEntity<UsersListDto> getAllUsers(Integer page, Integer size, String sortBy) {
        try {
            UsersListDto usersList=new UsersListDto();
            List<User> list=new ArrayList<>();
            Pageable paging = PageRequest.of(page, size, Sort.by(sortBy));

            Page<User> pagedResult=usersRepository.findAll(paging);
            if(pagedResult.hasContent()) {
                list=pagedResult.getContent();
            }

            int totalPages=0;
            Long count=usersRepository.count();
            if(count.intValue()%size==0){
                totalPages=count.intValue()/size;
            }else{
                totalPages=(count.intValue()/size)+1;
            }

            usersList.setUsers(list);
            usersList.setTotalPages(totalPages);
            usersList.setTotalUsers(count.intValue());
            usersList.setCurrentPage(page);

            return new ResponseEntity<>(usersList, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<User> getUser(Long id) {
        Optional<User> user = usersRepository.findById(id);

        if (user.isPresent()) {
            return new ResponseEntity<>(user.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @Override
    public ResponseEntity<User> saveUser(User user) {
        try {
            return new ResponseEntity<>(usersRepository.saveAndFlush(user), HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<User> updateUser(User user) {
        try {
            return new ResponseEntity<>(usersRepository.saveAndFlush(user), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<HttpStatus> deleteUser(Long id) {
        try {
            Optional<User> user = usersRepository.findById(id);
            if (user.isPresent()) {
                usersRepository.delete(user.get());
            }
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
