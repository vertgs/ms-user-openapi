package com.demo.msuseropenapi.service;

import com.demo.msuseropenapi.entity.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface UserServices {

    ResponseEntity<List<User>> getAllUsers(Integer pageNo, Integer pageSize, String sortBy);
    ResponseEntity<User> getUser(Long id);
    ResponseEntity<User> saveUser(User user);
    ResponseEntity<User> updateUser(User user);
    ResponseEntity<HttpStatus> deleteUser(Long id);
}
