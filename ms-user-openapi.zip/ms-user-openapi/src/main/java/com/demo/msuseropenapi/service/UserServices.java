package com.demo.msuseropenapi.service;

import com.demo.msuseropenapi.entity.User;
import com.demo.msuseropenapi.model.UsersListDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public interface UserServices {

    ResponseEntity<UsersListDto> getAllUsers(Integer page, Integer size, String sortBy);
    ResponseEntity<User> getUser(Long id);
    ResponseEntity<User> saveUser(User user);
    ResponseEntity<User> updateUser(User user);
    ResponseEntity<HttpStatus> deleteUser(Long id);
}
