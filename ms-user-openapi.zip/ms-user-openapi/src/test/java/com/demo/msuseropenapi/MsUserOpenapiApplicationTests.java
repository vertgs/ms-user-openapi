package com.demo.msuseropenapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsUserOpenapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
